/*
 * @(#)AWT_1_0_PopupBoxes.java				0.3-2 18/06/1999
 *
 *  This file is part of the HTTPClient package
 *  Copyright (C) 1996-1999  Ronald Tschal�r
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free
 *  Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA 02111-1307, USA
 *
 *  For questions, suggestions, bug-reports, enhancement-requests etc.
 *  I may be contacted at:
 *
 *  ronald@innovation.ch
 *
 */

package HTTPClient;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Event;
import java.awt.Color;
import java.awt.Button;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Rectangle;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;


/**
 * This file contains replacements for classes which use the AWT. The
 * versions in here use the old AWT event model used in JDK 1.0.2.
 *
 * @version	0.3-2  18/06/1999
 * @author	Ronald Tschal�r
 */

/**
 * This class implements a simple popup that request username and password
 * used for the "basic" and "digest" authentication schemes. It uses the
 * old AWT event model from JDK 1.0.2 .
 *
 * @version	0.3-2  18/06/1999
 * @author	Ronald Tschal�r
 */
class BasicAuthBox extends Frame
{
    private final static String title = "Authorization Request";
    private Dimension           screen;
    private Label               line1;
    private Label               line2;
    private Label               line3;
    private TextField           user;
    private TextField           pass;
    private int                 done;
    private final static int    OK = 1, CANCEL = 0;


    /**
     * Constructs the popup with three lines of text above the input fields
     */
    BasicAuthBox()
    {
	super(title);

	screen = getToolkit().getScreenSize();

	addNotify();
	setLayout(new BorderLayout());

	Panel p = new Panel();
	p.setLayout(new GridLayout(3,1));
	p.add(line1 = new Label());
	p.add(line2 = new Label());
	p.add(line3 = new Label());
	add("North", p);

	p = new Panel();
	p.setLayout(new GridLayout(2,1));
	p.add(new Label("Username:"));
	p.add(new Label("Password:"));
	add("West", p);
	p = new Panel();
	p.setLayout(new GridLayout(2,1));
	p.add(user = new TextField(30));
	p.add(pass = new TextField(30));
	pass.setEchoCharacter('*');
	add("East", p);

	p = new Panel();
	GridBagLayout gb = new GridBagLayout();
	p.setLayout(gb);
	GridBagConstraints constr = new GridBagConstraints();
	Panel pp = new Panel();
	p.add(pp);
	constr.gridwidth = GridBagConstraints.REMAINDER;
	gb.setConstraints(pp, constr);
	constr.gridwidth = 1;
	Button b;
	p.add(b = new Button("  OK  "));
	constr.weightx = 1.0;
	gb.setConstraints(b, constr);
	p.add(b = new Button("Clear"));
	constr.weightx = 2.0;
	gb.setConstraints(b, constr);
	p.add(b = new Button("Cancel"));
	constr.weightx   = 1.0;
	gb.setConstraints(b, constr);
	add("South", p);

	pack();
    }


    /**
     * our event handler
     */
    public boolean action(Event event, Object obj)
    {
	if (obj.equals("  OK  ")  ||  event.target == pass)
	{
	    done = OK;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Clear"))
	{
	    user.setText("");
	    pass.setText("");
	    user.requestFocus();
	    return true;
	}

	if (obj.equals("Cancel"))
	{
	    done = CANCEL;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.action(event, obj);
    }


    public boolean handleEvent(Event evt)
    {
	if (evt.id == Event.WINDOW_DESTROY)
	{
	    done = CANCEL;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.handleEvent(evt);
    }


    /**
     * the method called by MyAuthHandler.
     *
     * @return the username/password pair
     */
    synchronized NVPair getInput(String l1, String l2, String l3)
    {
	line1.setText(l1);
	line2.setText(l2);
	line3.setText(l3);

	line1.invalidate();
	line2.invalidate();
	line3.invalidate();

	setResizable(true);
	pack();
	setResizable(false);
	move((screen.width-preferredSize().width)/2,
	     (int) ((screen.height-preferredSize().height)/2*.7));
	show();
	user.requestFocus();

	try { wait(); } catch (InterruptedException e) { }

	hide();

	NVPair result = new NVPair(user.getText(), pass.getText());
	user.setText("");
	pass.setText("");

	if (done == CANCEL)
	    return null;
	else
	    return result;
    }
}


/**
 * A simple popup that asks whether the cookie should be accepted or rejected,
 * or if cookies from whole domains should be silently accepted or rejected.
 * It uses the old AWT event model from JDK 1.0.2 .
 *
 * @version	0.3-2  18/06/1999
 * @author	Ronald Tschal�r
 */
class BasicCookieBox extends Frame
{
    private final static String title = "Set Cookie Request";
    private Dimension           screen;
    GridBagLayout               layout;
    GridBagConstraints          constr;
    private Label		name_value_label;
    private Label		domain_value;
    private Label               ports_label;
    private Label               ports_value;
    private Label		path_value;
    private Label		expires_value;
    private Label               discard_note;
    private Label		secure_note;
    private Label		c_url_note;
    private Panel               left_panel;
    private Panel               right_panel;
    private Label               comment_label;
    private TextArea            comment_value;
    private TextField		domain;
    private Button		default_focus;
    private boolean             accept;
    private boolean             accept_domain;


    /**
     * Constructs the popup.
     */
    BasicCookieBox()
    {
	super(title);
	screen = getToolkit().getScreenSize();
	addNotify();

	setLayout(layout = new GridBagLayout());
	constr = new GridBagConstraints();

	Label header_label =
		new Label("The server would like to set the following cookie:");
	add(header_label);
	constr.gridwidth = GridBagConstraints.REMAINDER;
	constr.anchor = GridBagConstraints.WEST;
	layout.setConstraints(header_label, constr);

	Panel p = new Panel();
	left_panel = new Panel();
	left_panel.setLayout(new GridLayout(4,1));
	left_panel.add(new Label("Name=Value:"));
	left_panel.add(new Label("Domain:"));
	left_panel.add(new Label("Path:"));
	left_panel.add(new Label("Expires:"));
	ports_label = new Label("Ports:");
	p.add(left_panel);

	right_panel = new Panel();
	right_panel.setLayout(new GridLayout(4,1));
	right_panel.add(name_value_label = new Label());
	right_panel.add(domain_value = new Label());
	right_panel.add(path_value = new Label());
	right_panel.add(expires_value = new Label());
	ports_value = new Label();
	p.add(right_panel);
	add(p);
	layout.setConstraints(p, constr);
	secure_note = new Label("This cookie will only be sent over secure connections");
	discard_note = new Label("This cookie will be discarded at the end of the session");
	c_url_note = new Label("");
	comment_label = new Label("Comment:");
	comment_value = new TextArea("", 3, 45);
	comment_value.setEditable(false);

	add(p = new Panel());
	layout.setConstraints(p, constr);

	add(default_focus = new Button("Accept"));
	constr.gridwidth = 1;
	constr.anchor = GridBagConstraints.CENTER;
	constr.weightx = 1.0;
	layout.setConstraints(default_focus, constr);

	Button b;
	add(b= new Button("Reject"));
	constr.gridwidth = GridBagConstraints.REMAINDER;
	layout.setConstraints(b, constr);

	constr.weightx = 0.0;
	p = new Separator();
	add(p);
	constr.fill = GridBagConstraints.HORIZONTAL;
	layout.setConstraints(p, constr);

	header_label =
	    new Label("Accept/Reject all cookies from a host or domain:");
	add(header_label);
	constr.fill   = GridBagConstraints.NONE;
	constr.anchor = GridBagConstraints.WEST;
	layout.setConstraints(header_label, constr);

	p = new Panel();
	p.add(new Label("Host/Domain:"));
	p.add(domain = new TextField(30));
	add(p);
	layout.setConstraints(p, constr);

        header_label =
	    new Label("domains are characterized by a leading dot (`.')");
	add(header_label);
	layout.setConstraints(header_label, constr);
        header_label = new Label("(an empty string matches all hosts)");
	add(header_label);
	layout.setConstraints(header_label, constr);

	add(b = new Button("Accept All"));
	constr.anchor    = GridBagConstraints.CENTER;
	constr.gridwidth = 1;
	constr.weightx   = 1.0;
	layout.setConstraints(b, constr);

	add(b = new Button("Reject All"));
	constr.gridwidth = GridBagConstraints.REMAINDER;
	layout.setConstraints(b, constr);

	pack();

	constr.anchor    = GridBagConstraints.WEST;
	constr.gridwidth = GridBagConstraints.REMAINDER;
    }


    /**
     * our event handler
     */
    public boolean action(Event event, Object obj)
    {
	if (obj.equals("Accept"))
	{
	    accept = true;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Reject"))
	{
	    accept = false;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Accept All"))
	{
	    accept = true;
	    accept_domain = true;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Reject All"))
	{
	    accept = false;
	    accept_domain = true;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.action(event, obj);
    }


    public boolean handleEvent(Event evt)
    {
	if (evt.id == Event.WINDOW_DESTROY)
	{
	    accept = false;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.handleEvent(evt);
    }


    /**
     * the method called by the DefaultCookiePolicyHandler.
     *
     * @return the username/password pair
     */
    synchronized boolean accept(Cookie cookie, DefaultCookiePolicyHandler h,
				String server)
    {
	// set the new values

	name_value_label.setText(cookie.getName() + "=" + cookie.getValue());
	domain_value.setText(cookie.getDomain());
	path_value.setText(cookie.getPath());
	if (cookie.expires() == null)
	    expires_value.setText("never");
	else
	    expires_value.setText(cookie.expires().toString());
	int pos = 2;
	if (cookie.isSecure())
	{
	    add(secure_note, pos++);
	    layout.setConstraints(secure_note, constr);
	}
	if (cookie.discard())
	{
	    add(discard_note, pos++);
	    layout.setConstraints(discard_note, constr);
	}

	if (cookie instanceof Cookie2)
	{
	    Cookie2 cookie2 = (Cookie2) cookie;

	    // set ports list
	    if (cookie2.getPorts() != null)
	    {
		left_panel.setLayout(new GridLayout(5,1));
		left_panel.add(ports_label, 2);
		right_panel.setLayout(new GridLayout(5,1));
		int[] ports = cookie2.getPorts();
		StringBuffer plist = new StringBuffer();
		plist.append(ports[0]);
		for (int idx=1; idx<ports.length; idx++)
		{
		    plist.append(", ");
		    plist.append(ports[idx]);
		}
		ports_value.setText(plist.toString());
		right_panel.add(ports_value, 2);
	    }

	    // set comment url
	    if (cookie2.getCommentURL() != null)
	    {
		c_url_note.setText("For more info on this cookie see: " +
				    cookie2.getCommentURL());
		add(c_url_note, pos++);
		layout.setConstraints(c_url_note, constr);
	    }

	    // set comment
	    if (cookie2.getComment() != null)
	    {
		comment_value.setText(cookie2.getComment());
		add(comment_label, pos++);
		add(comment_value, pos++);
		layout.setConstraints(comment_label, constr);
		layout.setConstraints(comment_value, constr);
	    }
	}


	// invalidate all labels, so that new values are displayed correctly

	name_value_label.invalidate();
	domain_value.invalidate();
	ports_value.invalidate();
	path_value.invalidate();
	expires_value.invalidate();
	left_panel.invalidate();
	right_panel.invalidate();
	secure_note.invalidate();
	discard_note.invalidate();
	c_url_note.invalidate();
	comment_value.invalidate();
	invalidate();


	// set default domain test
 
	domain.setText(cookie.getDomain());


	// display

	setResizable(true);
	pack();
	setResizable(false);
	move((screen.width-preferredSize().width)/2,
	     (int) ((screen.height-preferredSize().height)/2*.7));
	show();
	default_focus.requestFocus();


	// wait for user input

	try { wait(); } catch (InterruptedException e) { }

	hide();


	// reset popup

	remove(secure_note);
	remove(discard_note);
	left_panel.remove(ports_label);
	left_panel.setLayout(new GridLayout(4,1));
	right_panel.remove(ports_value);
	right_panel.setLayout(new GridLayout(4,1));
	remove(c_url_note);
	remove(comment_label);
	remove(comment_value);


	// handle accept/reject domain buttons

	if (accept_domain)
	{
	    String dom = domain.getText().trim().toLowerCase();

	    if (accept)
		h.addAcceptDomain(dom);
	    else
		h.addRejectDomain(dom);

	    accept =
		accept != (dom.length() == 0  ||
			   dom.charAt(0) == '.'  &&  server.endsWith(dom)  ||
			   dom.charAt(0) != '.'  &&  server.equals(dom));
	}

	return accept;
    }
}


/**
 * A simple separator element.
 */
class Separator extends Panel
{
    public void paint(Graphics g)
    {
	int w = size().width,
	    h = size().height/2;

	g.setColor(Color.darkGray);
	g.drawLine(2, h-1, w-2, h-1);
	g.setColor(Color.white);
	g.drawLine(2, h, w-2, h);
    }

    public Dimension minimumSize()
    {
	return new Dimension(4, 2);
    }
}

